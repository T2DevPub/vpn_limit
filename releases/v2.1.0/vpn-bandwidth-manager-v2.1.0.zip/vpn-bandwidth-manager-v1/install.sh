#!/usr/bin/env bash
set -Eeuo pipefail

[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./install.sh"; exit 1; }
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_SRC="$BASE/scripts/vpn-bandwidth-v2"
CONF_SRC="$BASE/config/users.conf.example"

fail() { echo "ERROR: $*" >&2; exit 1; }

[[ -f /etc/os-release ]] || fail "Cannot identify operating system."
. /etc/os-release
[[ "${ID:-}" == ubuntu && "${VERSION_ID:-}" == 24.04 ]] || \
  fail "This package currently supports Ubuntu 24.04 only."

[[ -x /usr/local/openvpn_as/scripts/sacli ]] || \
  fail "OpenVPN Access Server is not installed. Install and start it first."

for cmd in python3 tc ip modprobe systemctl; do
  command -v "$cmd" >/dev/null || fail "Required command missing: $cmd"
done

echo "Installing required packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y iproute2 iptables python3

echo "Loading required kernel modules..."
for module in ifb sch_htb act_mirred cls_u32; do
  modprobe "$module" || fail "Cannot load kernel module: $module"
done

install -d -m 0755 /usr/local/sbin
install -d -m 0700 /etc/vpn-bandwidth /var/lib/vpn-bandwidth
install -d -m 0755 /var/log/vpn-bandwidth /run/lock
install -m 0755 "$SCRIPT_SRC" /usr/local/sbin/vpn-bandwidth-v2

if [[ ! -f /etc/vpn-bandwidth/users.conf ]]; then
  install -m 0600 "$CONF_SRC" /etc/vpn-bandwidth/users.conf
else
  echo "Existing users.conf preserved."
  chmod 0600 /etc/vpn-bandwidth/users.conf
fi

install -m 0644 "$BASE/modules/load-modules.conf" \
  /etc/modules-load.d/vpn-bandwidth.conf

# Create IFB devices only if missing. Do not change existing qdiscs or filters.
for dev in ifb0 ifb1; do
  if ! ip link show dev "$dev" >/dev/null 2>&1; then
    ip link add "$dev" type ifb
  fi
  ip link set dev "$dev" up
done

cat >/etc/systemd/system/vpn-bandwidth.service <<'UNIT'
[Unit]
Description=Per-session VPN bandwidth reconciliation
After=network-online.target openvpnas.service
Wants=network-online.target
ConditionPathExists=/usr/local/openvpn_as/scripts/sacli

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/vpn-bandwidth-v2 apply
RemainAfterExit=no

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload

echo
echo "INSTALLATION COMPLETE."
echo "No traffic-control qdiscs, filters, or bandwidth limits were applied."
echo "The service is installed but NOT enabled."
echo
echo "Next:"
echo "  1. Edit /etc/vpn-bandwidth/users.conf"
echo "  2. Run: /usr/local/sbin/vpn-bandwidth-v2 check"
echo "  3. Run: /usr/local/sbin/vpn-bandwidth-v2 plan"
echo "  4. Review tunnel/IFB mapping and existing qdiscs."
echo "  5. Only after approval, run: ./activate.sh"
