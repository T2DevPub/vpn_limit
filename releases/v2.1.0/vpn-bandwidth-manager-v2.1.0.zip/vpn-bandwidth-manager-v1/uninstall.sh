#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }
echo "This removes the manager files and service definition."
echo "It does NOT remove existing tc qdiscs, classes, filters, IFB devices, or state."
read -r -p "Type REMOVE to continue: " answer
[[ "$answer" == "REMOVE" ]] || exit 0
systemctl disable --now vpn-bandwidth.service 2>/dev/null || true
rm -f /etc/systemd/system/vpn-bandwidth.service
systemctl daemon-reload
rm -f /usr/local/sbin/vpn-bandwidth-v2 /etc/modules-load.d/vpn-bandwidth.conf
echo "Manager executable and service removed. Traffic-control state was left untouched."
