#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./activate.sh"; exit 1; }

echo "Pre-activation checks:"
/usr/local/sbin/vpn-bandwidth-v2 check
echo
/usr/local/sbin/vpn-bandwidth-v2 plan

echo
echo "This next action can modify traffic-control rules on the VPN interfaces."
read -r -p "Have you reviewed the qdiscs and confirmed as0t0->ifb1 / as0t1->ifb0? Type ACTIVATE to continue: " answer
[[ "$answer" == "ACTIVATE" ]] || { echo "Activation cancelled."; exit 0; }

# Apply once, interactively. Do not enable boot service until this succeeds.
 /usr/local/sbin/vpn-bandwidth-v2 apply
systemctl enable vpn-bandwidth.service
echo
echo "Bandwidth manager activated and boot service enabled."
