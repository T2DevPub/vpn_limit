VPN BANDWIDTH MANAGER V1.0
===========================

Purpose
-------
Install the proven vpn-bandwidth-v2.1.0 component on a fresh Ubuntu 24.04
server that already has OpenVPN Access Server installed.

IMPORTANT SAFETY BEHAVIOUR
--------------------------
- install.sh installs dependencies, the script, configuration directory,
  kernel module load list, IFB devices if absent, and a disabled systemd unit.
- install.sh does NOT run `vpn-bandwidth-v2 apply`.
- Existing users.conf is preserved.
- Existing qdiscs and filters are not replaced.
- activate.sh displays check and plan output and requires the exact word
  ACTIVATE before running apply and enabling the service.
- The uninstall script deliberately does not remove traffic-control state.

INSTALL
-------
1. Upload and extract this ZIP on the OpenVPN Access Server.
2. cd into the extracted vpn-bandwidth-manager-v1 directory.
3. Run:
     chmod +x install.sh activate.sh uninstall.sh
     ./install.sh

CONFIGURE
---------
Edit:
     nano /etc/vpn-bandwidth/users.conf

Format:
     USERNAME,DOWNLOAD_MBPS,UPLOAD_MBPS

Example:
     Tapan,20,10

0 means unlimited in that direction. Users not listed are unlimited.

VERIFY BEFORE ACTIVATION
------------------------
Run:
     /usr/local/sbin/vpn-bandwidth-v2 check
     /usr/local/sbin/vpn-bandwidth-v2 plan
     for dev in as0t0 as0t1 ifb0 ifb1; do
       echo "===== $dev ====="
       tc qdisc show dev "$dev"
       tc class show dev "$dev"
       tc filter show dev "$dev"
     done

Then confirm that the actual tunnel-to-IFB mapping is:
     as0t0 -> ifb1
     as0t1 -> ifb0

Only then run:
     ./activate.sh

COMPATIBILITY LIMITATION
------------------------
The supplied v2.1.0 engine has a fixed tunnel mapping:
     as0t0 -> ifb1
     as0t1 -> ifb0

It also expects HTB root handles 1: on tunnel interfaces and 2: on IFB
interfaces. It intentionally refuses to replace a different existing root
qdisc. This package does not dynamically adapt the engine to arbitrary
provider/OpenVPN interface layouts. Review before activation on every
different server build.

The systemd unit is installed but disabled until activation. A oneshot apply
at boot is provided; reconnect handling still depends on how OpenVPN AS
creates/recreates interfaces and should be tested on the target server.

This package contains the supplied bandwidth engine unchanged.
